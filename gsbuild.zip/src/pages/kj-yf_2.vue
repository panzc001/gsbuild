<template>
    <div class="wraper top_bg-cor">
        <page-header :isActive="isActive"></page-header>
        <!--top-menu-->
        <div class="about_nav-box kj_yf-box">
            <div class="about_ctn">
                <h2>科技+研发</h2>
                <div class="about_list">
                    <a href="/kj-yf_1">科技+研发</a>
                    <a class="active">建筑机械工程实验室</a>
                    <a href="/kj-yf_3">研究成果专利</a>
                </div>
            </div>
        </div>
        <div class="kj_yf-wrap">
            <div class="sys_tt animated fadeInUp">
                <h2>甘肃省建筑机械工程实验室有限公司</h2>
                <p>
                    甘肃省建筑机械工程实验室有限公司成立于2014年10月，注册资金3000万元，系甘肃建投装备制造有限公司的全资子公司，是省发展和改革委员会批复的省级工程研究中心（工程实验室）（甘发改高技〔2014〕1037号）。公司专业从事产品技术研发、技术咨询、技术转让、检验检测等业务，目前设有技术研发中心、专用汽车研究所（湖北十堰）、产业孵化中心、质量检查中心、测试中心等部门，拥有一支年轻化、技术强、专业精、具有创新协作精神的优秀团队，以及先进的研发设备、SOLIDWORKS等软件设施和理化检验、无损检测、液压试验台、淋雨试验房等检验检测设备。为甘肃建投装备制造有限公司及所属子公司产品更新换代，产品系列化及优化，提供了强有力的科技技术支撑。</p>
                <p>
                    公司历经两年的快速发展，完成了新品开发、新成果转化、关键技术的研究和新技术优化升级。目前已研发产品有混凝土泵车、混凝土搅拌运输车等混凝土机械，洒水车、洗扫车、压缩式垃圾车等环卫机械、高空作业车、广告车等市政车辆，通过了国家汽车质量监督检验中心（襄阳）的检测认可，拥有《混凝土搅拌运输车的专用去应力滚道》等实用新型专利7项，并对车辆行使动力性能等关键技术进行了研究，产品及技术服务等得到了客户的一致好评。</p>

                <p>
                    2016年10月，公司与武汉理工大学达成共建甘肃省建筑机械工程实验室的合作协议，公司作为武汉理工大学的硕士研究生的培训及实践基地。同月，与中汽认证中心、国家轿车质量监督检验中心达成战略协议，公司作为3C强制性认证检测中心、专用汽车产品定型试验和环保核准分支机构。</p>
                <p>公司始终坚持负重致远、科技导航、追求卓越、锐意进取的理念，以精湛先进的技术，良好的信誉保证，优越的技术咨询及检验检测能力力争成为与广大客户共同发展的最佳技术合作伙伴。</p>
            </div>
            <div class="pho_show animated pho_1">
                <h3>
                    <span>企业资质</span>
                    <em></em>
                </h3>
                <div class="phoo">
                    <img style="width: auto;" src="../assets/qyzh.png"/>
                </div>
            </div>
            <div class="pho_show animated pho_2">
                <h3>
                    <span>研发成果</span>
                    <em></em>
                </h3>
                <div class="phoo">
                    <ul>
                        <li>
                            <span>
                                <img src="../assets/cg_1.png"/>
                            </span>
                            <p>洗扫车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_2.png"/>
                            </span>
                            <p>餐厨垃圾车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_3.png"/>
                            </span>
                            <p>洒水车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_4.png"/>
                            </span>
                            <p>吸污车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_5.png"/>
                            </span>
                            <p>混凝土搅拌运输车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_6.png"/>
                            </span>
                            <p>混凝土搅拌运输车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_7.png"/>
                            </span>
                            <p>压缩式垃圾车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_8.png"/>
                            </span>
                            <p>车厢可卸式垃圾车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_9.png"/>
                            </span>
                            <p>广告宣传车</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/cg_10.png"/>
                            </span>
                            <p>高空作业车</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="pho_show animated pho_3">
                <h3>
                    <span>检验检测能力</span>
                    <em></em>
                </h3>
                <div class="phoo">
                    <ul>
                        <li>
                            <span>
                                <img src="../assets/jc_1.png"/>
                            </span>
                            <p>摆锤式冲击试验机</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/jc_2.png"/>
                            </span>
                            <p>液压试验台</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/jc_3.png"/>
                            </span>
                            <p>电子万能试验机</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/jc_4.png"/>
                            </span>
                            <p>磁粉探伤机</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/jc_5.png"/>
                            </span>
                            <p>油液污染检测仪</p>
                        </li>
                        <li>
                            <span>
                                <img src="../assets/jc_6.png"/>
                            </span>
                            <p>淋雨试验房</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="pho_show animated pho_4">
                <h3>
                    <span>员工风采</span>
                    <em></em>
                </h3>
                <ul class="ygfc">
                    <li>
                        <img src="../assets/fc_1.png"/>
                    </li>
                    <li>
                        <img src="../assets/fc_2.png"/>
                    </li>
                    <li>
                        <img src="../assets/fc_3.png"/>
                    </li>
                </ul>
            </div>
            <div class="pho_show animated pho_5">
                <h3>
                    <span>办公一角</span>
                    <em></em>
                </h3>
                <ul class="bgyj">
                    <li>
                        <img src="../assets/bgyj_1.png"/>
                    </li>
                    <li>
                        <img src="../assets/bgyj_2.png"/>
                    </li>
                </ul>
            </div>
        </div>
        <page-footer></page-footer>
    </div>
</template>
<script>
    import pageHeader from '../components/pageHeader.vue'
    import pageFooter from '../components/pageFooter.vue'
    import animate from 'animate.css'
    import $ from 'jquery'
    import Swiper from 'swiper'

    export default {
        components: {pageHeader, pageFooter},
        data() {
            return {
                isActive: {
                    index: false,
                    about: false,
                    dj: false,
                    xw: false,
                    pp: false,
                    zz: false,
                    kj: true,
                    yx: false,
                    lx: false,
                },
            }
        },
        mounted() {
            $(window).scroll(function () {
                const scrollTop = $(this).scrollTop();
                if (scrollTop > 0) {
                    $('.wraper,.nav_box').addClass('on');
                } else {
                    $('.wraper,.nav_box').removeClass('on');
                }
            });

            $(window).scroll(function () {
                const scrollTop = $(this).scrollTop();
                const scrop_1 = $('.pho_1').offset().top;
                const scrop_2 = $('.pho_2').offset().top;
                const scrop_3 = $('.pho_3').offset().top;
                const scrop_4 = $('.pho_4').offset().top;
                const scrop_5 = $('.pho_5').offset().top;
                if (scrollTop >= scrop_1 - 400 && scrollTop < scrop_2 - 400) {
                    $('.pho_1').addClass('fadeInUp');
                } else if (scrollTop >= scrop_2 - 400 && scrollTop < scrop_3 - 400) {
                    $('.pho_2').addClass('fadeInUp');
                } else if (scrollTop >= scrop_3 - 400 && scrollTop < scrop_4 - 400) {
                    $('.pho_3').addClass('fadeInUp');
                } else if (scrollTop >= scrop_4 - 400 && scrollTop < scrop_5 - 400) {
                    $('.pho_4').addClass('fadeInUp');
                } else if (scrollTop >= scrop_5 - 400) {
                    $('.pho_5').addClass('fadeInUp');
                }
            });
        }
    }
</script>